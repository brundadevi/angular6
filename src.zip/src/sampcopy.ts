import { Injectable } from '@angular/core';
import { Deto } from './deto';
import { InMemoryDbService } from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService {

  constructor() { }

  createDb() {
    const detoes = [
      { id: 1, jobcode: 'Mr. Nice',date:'2019-08-01',batchno:'11',random:'random' },
      { id: 2, jobcode: 'Narco',date:'2018-01-01',batchno:'12',random:'yayyyy' },
      { id: 3, jobcode: 'Bombasto',date:'2019-12-01',batchno:'100000000023',random:'random3' },
      { id: 4 , jobcode: 'Mr. Nice',date:'2019-01-01',batchno:'11',random:'random' },
      { id: 17, jobcode: 'Narco',date:'2018-01-01',batchno:'12',random:'random2' },
      { id: 16, jobcode: 'Bombasto',date:'2019-07-01',batchno:'12',random:'random3' },
      { id: 15, jobcode: 'Narco',date:'hello2',batchno:'11111111112',random:'raggggndom2' },
      { id: 14, jobcode: 'Narco',date:'t',batchno:'123',random:'random2' },
      { id: 13, jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 12, jobcode: 'Narco',date:'hello2',batchno:'12',random:'yayyyy' },
      { id: 11, jobcode: 'Bombasto',date:'hello',batchno:'100000000023',random:'random3' },
      { id: 10, jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 9, jobcode: 'Narco',date:'hello2',batchno:'12',random:'random2' },
      { id: 8, jobcode: 'Bombasto',date:'hello',batchno:'12',random:'random3' },
      { id: 7, jobcode: 'Narco',date:'hello2',batchno:'11111111112',random:'raggggndom2' },
      { id: 6, jobcode: 'Narco',date:'t',batchno:'123',random:'random2' },
      { id: 18, jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 19, jobcode: 'Narco',date:'hello2',batchno:'12',random:'yayyyy' },
      { id: 20, jobcode: 'Bombasto',date:'hello',batchno:'100000000023',random:'random3' },
      { id: 21 , jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 22, jobcode: 'Narco',date:'hello2',batchno:'12',random:'random2' },
      { id: 23, jobcode: 'Bombasto',date:'hello',batchno:'12',random:'random3' },
      { id: 25, jobcode: 'Narco',date:'hello2',batchno:'11111111112',random:'raggggndom2' },
      { id: 24, jobcode: 'Narco',date:'t',batchno:'123',random:'random2' },
      { id: 33, jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 32, jobcode: 'Narco',date:'hello2',batchno:'12',random:'yayyyy' },
      { id: 31, jobcode: 'Bombasto',date:'hello',batchno:'100000000023',random:'random3' },
      { id: 30, jobcode: 'Mr. Nice',date:'hello',batchno:'11',random:'random' },
      { id: 29, jobcode: 'Narco',date:'hello2',batchno:'12',random:'random2' },
      { id: 28, jobcode: 'Bombasto',date:'hello',batchno:'12',random:'random3' },
      { id: 27, jobcode: 'Narco',date:'hello2',batchno:'11111111112',random:'raggggndom2' },
      { id: 26, jobcode: 'Narco',date:'t',batchno:'123',random:'random2' }
    ];
    return {detoes};
  }

  // Overrides the genId method to ensure that a hero always has an id.
  // If the heroes array is empty,
  // the method below returns the initial number (11).
  // if the heroes array is not empty, the method below returns the highest
  // hero id + 1.
  genId(detoes: Deto[]): number {
    return detoes.length > 0 ? Math.max(...detoes.map(deto => deto.id)) + 1 : 1;
  }
}





