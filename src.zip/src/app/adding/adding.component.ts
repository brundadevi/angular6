import { Component, OnInit } from '@angular/core';
import { Deto } from '../deto';
import { DatahandlingService } from '../datahandling.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-adding',
  templateUrl: './adding.component.html',
  styleUrls: ['./adding.component.css']
})
export class AddingComponent implements OnInit {
  //det : Deto;
 usermodel : Deto;
dates:string;

bob: Deto; 
OnSubmit(uf:NgForm)
{


  this.bob = {
  
    id:1234,
    
    jobcode:uf.value.jc ,
    date:uf.value.date,
    batchno:uf.value.bno,
    random:uf.value.random
  };

  this.dates=uf.value.date;

  let newDate = new Date(this.dates);
  console.log("oyeee!!!");
  console.log(newDate);
  console.log(this.dates[2]);
  console.log("vvvvoyeee!!!");
  if(!this.bob.jobcode)
{this.bob.jobcode='fgege';
  
}
  this.addDetoes();
 
  //console.log(uf.value.date);
}

  constructor(private ds:DatahandlingService) { }
detoes: Deto[]=[];
dm:Deto[]=[];
  ngOnInit() {
    
    
  }
  getDetoes(): void {
    this.ds.getDetoes()
    .subscribe(detoes => {this.detoes = detoes;
    console.log(this.detoes[2].jobcode);
     // this.dm=this.detoes;
      this.passingDet(this.detoes);
  })
    console.log("FDhfehgoiegelhgeiojng");
   this.dm=this.detoes;
   
  }


   bob9: Deto = {
  
    id: 35,
    jobcode:'dfdfd' , 
    date:'fdfd',
    batchno:3,
    random:'fdfd',
};

 
 
passingDet(sam:Deto[])
{

  console.log(sam[0].jobcode);
}

  addDetoes() :any{
    this.ds.addDeto(this.bob)
    .subscribe(detoes => console.log('Success',detoes))

    this.getDetoes(); 
  }

// //b='dfd';



//   add(name: string): void {
//     name = name.trim();
//     if (!name) { return; }
//    // this.ds.addDeto({this.a:number, name:string,  this.b:string, this.c:number, this.d:string } as Deto)
//           .subscribe(deto => {
//         this.detoes.push(deto);
//       });
 // }--------------------------------------------------------------------
}
