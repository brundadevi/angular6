import { TestBed } from '@angular/core/testing';

import { DatahandlingService } from './datahandling.service';

describe('DatahandlingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DatahandlingService = TestBed.get(DatahandlingService);
    expect(service).toBeTruthy();
  });
});
