import { Component, OnInit } from '@angular/core';
import { Deto } from '../deto';
import { DatahandlingService } from '../datahandling.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  dates1:string;dates2:string;
  toggle:number=0;
      bob: Deto;
  detoes: Deto[]=[];
  deto2:Deto[]=[];
  kum:string="";plz:string;
bn:number=0;
j:number=0;k:number=0;l:number=0;
newDate1:Date;newDate2:Date;

//--------------------------------------------------
constructor(private ds:DatahandlingService)
     { 

      }
//--------------------------------------------------
  ngOnInit() {
  } 
  
//--------------------------------------------------
  OnSubmit(uf:NgForm)
{

this.toggle=1;
  console.log(uf.value);
  this.kum=uf.value.jc;
  this.bn=uf.value.bno;
  this.getDetoes();

  this.dates1=uf.value.date1;
  this.dates2=uf.value.date2;
   this.newDate1 = new Date(this.dates1);
  this.newDate2 = new Date(this.dates2);
  /* console.log("oyeee!!!");
  console.log(newDate1);console.log(newDate2);
  console.log(this.dates1[2]);
  console.log("vvvvoyeee!!!");
  if(newDate1>newDate2)
  {
    console.log("atlast!!!!");
  }
  else{
    console.log("thats fine!!")
  } */

 //console.log("@@@@!!!!fwfs"+uf.value.bno);

}

//--------------------------------------------------
getDetoes(): void {
 this.ds.getDetoes()
  .subscribe(detoes => {this.detoes = detoes;
  console.log(this.detoes[2].jobcode);
   // this.dm=this.detoes;
    this.passingDet(this.detoes);
})
}

//-------------------------------------------------------
passingDet(x:Deto[])
{
  if(this.kum && this.bn)
  {
    this.searchjcbn(this.kum,this.bn,x,this.newDate1,this.newDate2);
  }
  else if(this.kum){
  this.searchjc(this.kum,x,this.newDate1,this.newDate2);}
  else if(this.bn)
  {
    this.searchbn(this.bn,x,this.newDate1,this.newDate2);
  }
  //console.log(x);
  //console.log("Gdgd"+this.kum);

}
//--------------------------------------------------
searchjc(str:string,x:Deto[],datm:Date,datk:Date)
{
console.log("inside the passingdetmethod");
console.log("op"+str);
console.log(x); 
for(let i=0;i<x.length ;i++)

{
  if(x[i].jobcode==str)
  {
    let dateComp = new Date(x[i].date);
    if(datm<=dateComp && datk >= dateComp)
    {

    this.deto2[this.j]=x[i];
    console.log("fsglp");
  console.log(this.deto2[this.j]);
  this.j++;
    }
  }

}
}
//--------------------------------------------------

searchbn(str:number,x:Deto[],datm:Date,datk:Date)
{
  console.log("%%%%%%%%%%%%%%%%5");
console.log("op"+str);
console.log(x); 
for(let i=0;i<x.length ;i++)

{
  if(x[i].batchno==str)
  {
    //console.log("#################");
    let dateComp = new Date(x[i].date);
    if(datm<=dateComp && datk >= dateComp)
    {

    
    //let newDate3 = new Date(x[i].date);
    //this.plz=this.x[i].date;
    this.deto2[this.k]=x[i];
   // console.log("bno baaluu srii dudeeeeeeee"+datm);
 // console.log(this.deto2[this.k]);
  this.k++;
  }
}

}
}
//--------------------------------------------------
searchjcbn(str:string,str2:number,x:Deto[],datm:Date,datk:Date)
{
  console.log("@@@@@@@@");
console.log("op"+str);
console.log(x); 
for(let i=0;i<x.length ;i++)

{
  if(x[i].batchno==str2 && x[i].jobcode==str)
  {
    let dateComp = new Date(x[i].date);
    if(datm<=dateComp && datk >= dateComp)
    {
    this.deto2[this.l]=x[i];
    console.log("bno and jc dudeeeeeeee");
  console.log(this.deto2[this.l]);
  this.l++;
    }
}


}
}
//--------------------------------------------------
}
